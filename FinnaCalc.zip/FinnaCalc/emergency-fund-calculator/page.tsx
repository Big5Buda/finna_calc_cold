"use client"

import { useState } from "react"
import { Calculator, ArrowLeft, Share2, Download } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import Link from "next/link"

export default function EmergencyFundCalculator() {
  const [monthlyExpenses, setMonthlyExpenses] = useState("")
  const [currentSavings, setCurrentSavings] = useState("")
  const [targetMonths, setTargetMonths] = useState("6")
  const [result, setResult] = useState<any>(null)

  const calculateEmergencyFund = () => {
    const expenses = Number.parseFloat(monthlyExpenses) || 0
    const savings = Number.parseFloat(currentSavings) || 0
    const months = Number.parseFloat(targetMonths) || 6

    const targetAmount = expenses * months
    const stillNeeded = Math.max(0, targetAmount - savings)
    const percentComplete = savings > 0 ? (savings / targetAmount) * 100 : 0

    setResult({
      targetAmount,
      stillNeeded,
      percentComplete: Math.min(100, percentComplete),
      monthsOfExpensesCovered: savings > 0 ? savings / expenses : 0,
    })
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="border-b border-gray-200 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Link href="/" className="flex items-center">
                <Calculator className="h-8 w-8 text-blue-600" />
                <span className="ml-2 text-xl font-bold text-gray-900">FinnaCalc</span>
              </Link>
            </div>
            <Link href="/">
              <Button variant="outline" className="flex items-center gap-2">
                <ArrowLeft className="h-4 w-4" />
                Back to Home
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Breadcrumb */}
        <nav className="mb-8">
          <ol className="flex items-center space-x-2 text-sm text-gray-500">
            <li>
              <Link href="/" className="hover:text-blue-600">
                Home
              </Link>
            </li>
            <li>/</li>
            <li className="text-gray-900">Emergency Fund Calculator</li>
          </ol>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Calculator */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="h-6 w-6 text-blue-600" />
                  Emergency Fund Calculator
                </CardTitle>
                <CardDescription>
                  Calculate how much you need in your emergency fund and track your progress
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="monthlyExpenses">Monthly Expenses ($)</Label>
                    <Input
                      id="monthlyExpenses"
                      type="number"
                      placeholder="5000"
                      value={monthlyExpenses}
                      onChange={(e) => setMonthlyExpenses(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="currentSavings">Current Emergency Savings ($)</Label>
                    <Input
                      id="currentSavings"
                      type="number"
                      placeholder="10000"
                      value={currentSavings}
                      onChange={(e) => setCurrentSavings(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="targetMonths">Target Months of Expenses</Label>
                    <Input
                      id="targetMonths"
                      type="number"
                      placeholder="6"
                      value={targetMonths}
                      onChange={(e) => setTargetMonths(e.target.value)}
                    />
                  </div>
                </div>

                <Button onClick={calculateEmergencyFund} className="w-full bg-blue-600 hover:bg-blue-700" size="lg">
                  Calculate Emergency Fund
                </Button>

                {result && (
                  <div className="calculator-result space-y-4">
                    <h3 className="text-lg font-semibold text-blue-800">Your Emergency Fund Analysis</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-gray-600">Target Emergency Fund</p>
                        <p className="text-2xl font-bold text-green-600">${result.targetAmount.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Still Need to Save</p>
                        <p className="text-2xl font-bold text-red-600">${result.stillNeeded.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Progress Complete</p>
                        <p className="text-2xl font-bold text-blue-600">{result.percentComplete.toFixed(1)}%</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Current Coverage</p>
                        <p className="text-2xl font-bold text-purple-600">
                          {result.monthsOfExpensesCovered.toFixed(1)} months
                        </p>
                      </div>
                    </div>

                    <div className="flex gap-2 pt-4">
                      <Button variant="outline" className="flex items-center gap-2">
                        <Share2 className="h-4 w-4" />
                        Share Results
                      </Button>
                      <Button variant="outline" className="flex items-center gap-2">
                        <Download className="h-4 w-4" />
                        Download PDF
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Ad Space */}
            <div className="ad-space">
              <p>Advertisement</p>
              <p className="text-sm">High-Yield Savings Accounts</p>
            </div>

            {/* Email Capture */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Get Financial Tips</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <Input placeholder="Enter your email" />
                  <Button className="w-full bg-blue-600 hover:bg-blue-700">Get Free Tips</Button>
                </div>
              </CardContent>
            </Card>

            {/* Related Calculators */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Related Calculators</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Link href="/savings-calculator" className="block p-2 hover:bg-gray-50 rounded">
                    <p className="font-medium">Savings Calculator</p>
                    <p className="text-sm text-gray-600">Calculate savings growth</p>
                  </Link>
                  <Link href="/budget-calculator" className="block p-2 hover:bg-gray-50 rounded">
                    <p className="font-medium">Budget Calculator</p>
                    <p className="text-sm text-gray-600">Plan your monthly budget</p>
                  </Link>
                  <Link href="/debt-payoff-calculator" className="block p-2 hover:bg-gray-50 rounded">
                    <p className="font-medium">Debt Payoff Calculator</p>
                    <p className="text-sm text-gray-600">Plan debt elimination</p>
                  </Link>
                </div>
              </CardContent>
            </Card>

            {/* Premium Upgrade */}
            <Card className="border-blue-200 bg-blue-50">
              <CardHeader>
                <CardTitle className="text-lg text-blue-800">Upgrade to Premium</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-blue-700 mb-3">Get advanced features:</p>
                <ul className="text-sm text-blue-700 space-y-1 mb-4">
                  <li>• Detailed PDF reports</li>
                  <li>• Save calculations</li>
                  <li>• Advanced scenarios</li>
                  <li>• Priority support</li>
                </ul>
                <Button className="w-full bg-blue-600 hover:bg-blue-700">Upgrade Now - $19/month</Button>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* SEO Content */}
        <div className="mt-12 prose max-w-none">
          <h2>How to Use the Emergency Fund Calculator</h2>
          <p>
            An emergency fund is a crucial financial safety net that can help you weather unexpected expenses like
            medical bills, car repairs, or job loss. Our emergency fund calculator helps you determine how much you
            should save and tracks your progress toward your goal.
          </p>

          <h3>Why You Need an Emergency Fund</h3>
          <ul>
            <li>Protects against unexpected expenses</li>
            <li>Prevents debt accumulation during emergencies</li>
            <li>Provides peace of mind and financial security</li>
            <li>Helps maintain your lifestyle during income disruptions</li>
          </ul>

          <h3>How Much Should You Save?</h3>
          <p>
            Financial experts typically recommend saving 3-6 months of living expenses. However, your ideal emergency
            fund size depends on factors like job stability, family size, and monthly expenses.
          </p>
        </div>
      </div>
    </div>
  )
}
