"use client"

import { useState } from "react"
import { Calculator, ArrowLeft, Share2, Download } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Link from "next/link"

export default function LoanCalculator() {
  const [loanAmount, setLoanAmount] = useState("")
  const [interestRate, setInterestRate] = useState("")
  const [loanTerm, setLoanTerm] = useState("")
  const [loanType, setLoanType] = useState("personal")
  const [result, setResult] = useState<any>(null)

  const calculateLoan = () => {
    const principal = Number.parseFloat(loanAmount) || 0
    const rate = (Number.parseFloat(interestRate) || 0) / 100 / 12
    const term = Number.parseFloat(loanTerm) || 0

    if (principal <= 0 || rate < 0 || term <= 0) {
      setResult({ error: "Please enter valid positive numbers" })
      return
    }

    const monthlyPayment = (principal * rate * Math.pow(1 + rate, term)) / (Math.pow(1 + rate, term) - 1)
    const totalPayment = monthlyPayment * term
    const totalInterest = totalPayment - principal

    setResult({
      monthlyPayment,
      totalPayment,
      totalInterest,
      principal,
    })
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="border-b border-gray-200 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Link href="/" className="flex items-center">
                <Calculator className="h-8 w-8 text-blue-600" />
                <span className="ml-2 text-xl font-bold text-gray-900">FinnaCalc</span>
              </Link>
            </div>
            <Link href="/">
              <Button variant="outline" className="flex items-center gap-2">
                <ArrowLeft className="h-4 w-4" />
                Back to Home
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <nav className="mb-8">
          <ol className="flex items-center space-x-2 text-sm text-gray-500">
            <li>
              <Link href="/" className="hover:text-blue-600">
                Home
              </Link>
            </li>
            <li>/</li>
            <li className="text-gray-900">Loan Payment Calculator</li>
          </ol>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="h-6 w-6 text-blue-600" />
                  Loan Payment Calculator
                </CardTitle>
                <CardDescription>Calculate monthly payments for any type of loan</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="loanType">Loan Type</Label>
                    <Select value={loanType} onValueChange={setLoanType}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select loan type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="personal">Personal Loan</SelectItem>
                        <SelectItem value="business">Business Loan</SelectItem>
                        <SelectItem value="auto">Auto Loan</SelectItem>
                        <SelectItem value="mortgage">Mortgage</SelectItem>
                        <SelectItem value="student">Student Loan</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="loanAmount">Loan Amount ($)</Label>
                    <Input
                      id="loanAmount"
                      type="number"
                      placeholder="50000"
                      value={loanAmount}
                      onChange={(e) => setLoanAmount(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="interestRate">Annual Interest Rate (%)</Label>
                    <Input
                      id="interestRate"
                      type="number"
                      step="0.01"
                      placeholder="5.5"
                      value={interestRate}
                      onChange={(e) => setInterestRate(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="loanTerm">Loan Term (months)</Label>
                    <Input
                      id="loanTerm"
                      type="number"
                      placeholder="60"
                      value={loanTerm}
                      onChange={(e) => setLoanTerm(e.target.value)}
                    />
                  </div>
                </div>

                <Button onClick={calculateLoan} className="w-full bg-blue-600 hover:bg-blue-700" size="lg">
                  Calculate Loan Payment
                </Button>

                {result && (
                  <div className="calculator-result space-y-4">
                    {result.error ? (
                      <div className="text-red-600 font-semibold">{result.error}</div>
                    ) : (
                      <>
                        <h3 className="text-lg font-semibold text-blue-800">Your Loan Payment Details</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <p className="text-sm text-gray-600">Monthly Payment</p>
                            <p className="text-3xl font-bold text-green-600">${result.monthlyPayment.toFixed(2)}</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-600">Total Payment</p>
                            <p className="text-2xl font-bold text-blue-600">${result.totalPayment.toLocaleString()}</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-600">Total Interest</p>
                            <p className="text-2xl font-bold text-red-600">${result.totalInterest.toLocaleString()}</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-600">Principal Amount</p>
                            <p className="text-2xl font-bold text-purple-600">${result.principal.toLocaleString()}</p>
                          </div>
                        </div>

                        <div className="bg-gray-50 p-4 rounded-lg">
                          <h4 className="font-semibold mb-2">Payment Breakdown:</h4>
                          <div className="flex justify-between text-sm">
                            <span>Principal: {((result.principal / result.totalPayment) * 100).toFixed(1)}%</span>
                            <span>Interest: {((result.totalInterest / result.totalPayment) * 100).toFixed(1)}%</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                            <div
                              className="bg-blue-600 h-2 rounded-full"
                              style={{ width: `${(result.principal / result.totalPayment) * 100}%` }}
                            ></div>
                          </div>
                        </div>

                        <div className="flex gap-2 pt-4">
                          <Button variant="outline" className="flex items-center gap-2">
                            <Share2 className="h-4 w-4" />
                            Share Results
                          </Button>
                          <Button variant="outline" className="flex items-center gap-2">
                            <Download className="h-4 w-4" />
                            Download Amortization Schedule
                          </Button>
                        </div>
                      </>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="ad-space">
              <p>Advertisement</p>
              <p className="text-sm">Best Loan Rates - Compare Now</p>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Find Better Rates</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-3">Compare loan offers from top lenders</p>
                <Button className="w-full bg-green-600 hover:bg-green-700">Compare Loan Rates</Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Related Calculators</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Link href="/mortgage-calculator" className="block p-2 hover:bg-gray-50 rounded">
                    <p className="font-medium">Mortgage Calculator</p>
                    <p className="text-sm text-gray-600">Calculate home loan payments</p>
                  </Link>
                  <Link href="/auto-loan-calculator" className="block p-2 hover:bg-gray-50 rounded">
                    <p className="font-medium">Auto Loan Calculator</p>
                    <p className="text-sm text-gray-600">Calculate car loan payments</p>
                  </Link>
                  <Link href="/debt-consolidation-calculator" className="block p-2 hover:bg-gray-50 rounded">
                    <p className="font-medium">Debt Consolidation</p>
                    <p className="text-sm text-gray-600">Compare consolidation options</p>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* SEO Content */}
        <div className="mt-12 prose max-w-none">
          <h2>How to Use the Loan Calculator</h2>
          <p>
            Our loan calculator helps you determine monthly payments for various types of loans including personal
            loans, business loans, auto loans, mortgages, and student loans. Understanding your loan payments is crucial
            for budgeting and financial planning.
          </p>

          <h3>Types of Loans We Calculate</h3>
          <ul>
            <li>
              <strong>Personal Loans:</strong> Unsecured loans for personal expenses
            </li>
            <li>
              <strong>Business Loans:</strong> Financing for business operations and growth
            </li>
            <li>
              <strong>Auto Loans:</strong> Vehicle financing with competitive rates
            </li>
            <li>
              <strong>Mortgages:</strong> Home loans with various term options
            </li>
            <li>
              <strong>Student Loans:</strong> Education financing options
            </li>
          </ul>

          <h3>Factors That Affect Your Loan Payment</h3>
          <p>
            Your monthly loan payment depends on three main factors: the loan amount (principal), the interest rate, and
            the loan term. Generally, longer terms result in lower monthly payments but higher total interest costs.
          </p>
        </div>
      </div>
    </div>
  )
}
